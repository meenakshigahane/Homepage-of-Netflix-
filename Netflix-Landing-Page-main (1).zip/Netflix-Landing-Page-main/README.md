# Netflix-Landing-Page
This is clone for Netflix Landing Page.This Page is created using HTML,CSS and little code of JavaScript. 
JavaScript is used in this code for handing the event in the Elements.
